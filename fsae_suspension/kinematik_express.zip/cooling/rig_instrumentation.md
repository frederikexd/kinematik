# Cooling rig — can it measure what it is for?

The rig has to resolve heat rejection to **±10%** to be worth building — below that it cannot tell two radiator designs apart, and it cannot validate a CFD model to any tolerance anyone will accept in a design review.

Load 6.58 kW, flow 12 L/min, 50/50 ethylene glycol / water → **ΔT = 9.04 K**. Everything below follows from how small that number is.

### A typical first sensor list

**This rig cannot do its job.** ±11.5% on heat rejection against a ±10% target — it cannot distinguish two radiators that differ by less than about 23%, and a summer of data will not settle any argument you build it to settle.

- ΔT at this load and flow is **9.04 K**.
- PT100 class B: ±(0.3 + 0.005·|T|) — 0.65 °C at 70 °C. → two independent sensors give ±0.65 × √2 = ±0.919 K on the difference.
- Paddle-wheel: ±5 % of reading, and worse near the bottom of its range.
- Contributions: flow ±5.0%, ΔT ±10.2%, cp ±2.0% → total ±11.5% (root-sum-square).
- **temperature difference dominates.** Spending money anywhere else first is spending it in the wrong place.
- The temperature term is the largest and it is also the cheapest to fix: a matched PT100 pair measures the difference directly and cancels most of the common-mode error. Same money as two good absolute sensors, several times the resolution.

### The whole matrix

| temperature | flow | ΔT term | flow term | total | meets target |
|---|---|---|---|---|---|
| Type K thermocouple | Paddle-wheel | ±34.4% | ±5.0% | **±34.8%** | — |
| Type K thermocouple | Turbine | ±34.4% | ±3.0% | **±34.6%** | — |
| Type K thermocouple | Coriolis mass flow | ±34.4% | ±0.2% | **±34.5%** | — |
| PT100 class B | Paddle-wheel | ±10.2% | ±5.0% | **±11.5%** | — |
| PT100 class B | Turbine | ±10.2% | ±3.0% | **±10.8%** | — |
| PT100 class B | Coriolis mass flow | ±10.2% | ±0.2% | **±10.4%** | — |
| PT100 class A | Paddle-wheel | ±4.5% | ±5.0% | **±7.0%** | ✅ |
| PT100 class A | Turbine | ±4.5% | ±3.0% | **±5.8%** | ✅ |
| PT100 class A | Coriolis mass flow | ±4.5% | ±0.2% | **±5.0%** | ✅ |
| PT100 1/10 DIN | Paddle-wheel | ±1.0% | ±5.0% | **±5.5%** | ✅ |
| PT100 1/10 DIN | Turbine | ±1.0% | ±3.0% | **±3.7%** | ✅ |
| PT100 1/10 DIN | Coriolis mass flow | ±1.0% | ±0.2% | **±2.3%** | ✅ |
| Matched PT100 pair on ΔT | Paddle-wheel | ±0.6% | ±5.0% | **±5.4%** | ✅ |
| Matched PT100 pair on ΔT | Turbine | ±0.6% | ±3.0% | **±3.6%** | ✅ |
| Matched PT100 pair on ΔT | Coriolis mass flow | ±0.6% | ±0.2% | **±2.1%** | ✅ |

**Cheapest combination that works: PT100 class A + Paddle-wheel**, at ±7.0%.

### Two structural fixes, both decided before the hoses are cut

**1 · Design the rig to run below the car's flow rate.** The error is a fraction of ΔT, so halving the flow doubles ΔT and halves the temperature term outright: at 6 L/min the same PT100-B + turbine list gives ±6.2% instead of ±10.8%. That needs a throttling valve and a bypass — two fittings, decided now, impossible to retrofit cleanly later.

To hit ±10% with class-B PT100s and a turbine meter at all, the rig must be run at a ΔT of at least **9.9 K**. Size the throttling range around that number, not around the car's operating point.

**2 · Measure the difference, not two temperatures.** A matched PT100 pair is calibrated together so common-mode error cancels; it costs about what two good absolute sensors cost and resolves several times better. If you buy one thing off this page, buy that.

### What else the rig should be instrumented for

- **Pressure, both sides of the pump and across the radiator.** Without it you cannot separate a flow problem from a heat-transfer problem, and every confusing result will be one of those two.
- **Air-side inlet temperature and face velocity.** Heat rejection quoted without the air-side condition is not a number anyone can reuse, including you in September.
- **A repeatability run.** Run the same point three times on different days before trusting any comparison; the spread you get is the real error bar, and it is usually worse than the one computed here.

*Root-sum-square propagation through Q = ρ·V̇·cp·ΔT, assuming independent errors and a 2 % uncertainty on cp. Systematic errors — a sensor in a fitting reading wall temperature instead of fluid, an un-developed flow profile at the meter — are not in here and are usually larger than everything that is.*
