# Cooling loop sizing

**⚠️** Loop at 80 kW shaft power.

- 80.0 kW shaft at 94% motor × 97% inverter → 7.74 kW of loss.
- 85% of that loss assumed to reach the coolant (6.58 kW); the rest leaves through the housings. That split is an assumption, and it is the one to measure first on the rig.

| quantity | value |
|---|---|
| heat into coolant | **6.58 kW** |
| ΔT across the load | **9.0 K** |
| mass flow | 0.214 kg/s |
| radiator UA required | **439 W/K** |
| UA margin | 0.27× |
| steady coolant temperature | **89.8 °C** |
| time to limit with no radiator | 21 s |
| margin to boiling | 19 °C |

- 50/50 ethylene glycol / water: cp 3400 J/kg·K, ρ 1070 kg/m³. About 19 % less heat capacity than water. The freeze protection is worthless in a summer competition and you pay for it in radiator area.
- 12 L/min → 0.2140 kg/s → **9.0 K rise** across the load at 6.58 kW.
- Radiator needs **439 W/K** to hold 50 °C against 35 °C ambient; you have 120 W/K (0.27× margin).
- ⚠️ The radiator is undersized for this load at this ambient. The loop will keep climbing until the coolant is hot enough to shed the heat — which is what `steady coolant` below tells you, and it is above your limit.
- With the radiator ignored entirely, the loop's own thermal mass buys only **21 s** before the limit. That is the number that matters for Acceleration and Skidpad, where the car is done before the radiator has done anything.

### Coolant choice is worth 1.15× on ΔT

Same load and flow on distilled water: **7.9 K** instead of 9.0 K, and 439 W/K of radiator instead of 439. Glycol buys freeze protection you do not need in July and costs radiator area you do.

*Lumped steady-state: one heat source, one radiator, a constant UA and no air-side model. It sizes the radiator and it does not predict a transient — the pack thermal and rig files are where transients live.*
