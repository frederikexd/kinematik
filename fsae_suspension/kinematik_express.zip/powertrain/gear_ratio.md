# Gear ratio — swept, not blocked

Motor 140 Nm / 80 kW, wheel radius 228 mm, car 280 kg, μ 1.55.

> **This did not need the output shaft CAD.** A ratio sweep needs the motor curve, the rolling radius and the mass — the shaft is sized *from* the ratio, not before it. If gear ratio is being held behind shaft geometry on a schedule, that dependency runs the wrong way and it is costing weeks.

| objective | best final drive | 0–75 km/h (s) | top speed (km/h) |
|---|---|---|---|
| accel | **4.25** | 4.41 | 120.6 |
| balanced | **4.25** | 4.41 | 120.6 |
| topspeed | **3** | 5.26 | 170.1 |

The three objectives disagreeing is the actual result. FSAE scoring weights Acceleration and Autocross far above top speed, so the acceleration-biased ratio is usually right — but check it against the longest straight on your event's track before committing, because a redline-limited car on that straight loses more than the launch gains.

| final drive | top (km/h) | at redline (km/h) | 0–75 (s) | launch force (N) | grip limited |
|---|---|---|---|---|---|
| 2.5 | 161.1 | 206.3 | 5.78 | 1382 | no |
| 2.75 | 169.2 | 187.5 | 5.505 | 1520 | no |
| 3 | 170.1 | 171.9 | 5.26 | 1658 | no |
| 3.25 | 158.4 | 158.7 | 5.05 | 1796 | no |
| 3.5 | 146.7 | 147.3 | 4.86 | 1934 | no |
| 3.75 | 136.8 | 137.5 | 4.69 | 2072 | no |
| 4 | 128.7 | 128.9 | 4.54 | 2211 | no |
| 4.25 | 120.6 | 121.3 | 4.41 | 2349 | yes |
| 4.5 | 114.3 | 114.6 | 4.41 | 2487 | yes |
| 4.75 | 108 | 108.6 | 4.42 | 2625 | yes |
| 5 | 102.6 | 103.1 | 4.445 | 2763 | yes |
| 5.25 | 98.1 | 98.23 | 4.48 | 2901 | yes |
| 5.5 | 93.6 | 93.77 | 4.525 | 3039 | yes |
| 5.75 | 89.1 | 89.69 | 4.58 | 3178 | yes |
| 6 | 85.5 | 85.95 | 4.64 | 3316 | yes |

**Grip-limited launch is the line to read.** Where it says yes, more ratio buys nothing — the tyre is already the constraint and you are just adding driveline torque for the mounts to react.

### Sprockets for the chosen ratio

- 14T → 60T gives **4.286** against a target of 4.25
- Chain: #35 (3/8")

*Point-mass longitudinal model with a synthesised motor curve from peak torque and power. Replace it with your dyno pull — the shape between base speed and redline is exactly what decides this, and a synthesised curve is smoother than any real motor.*
