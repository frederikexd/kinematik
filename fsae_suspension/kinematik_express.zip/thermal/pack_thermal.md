# Pack thermal — one autocross lap

Layout **6 × 14** cells.

- Hottest cell at the end of the lap: **35.76 °C**
- Coolest: 35.76 °C · spread **0 °C**
- Cells over 60 °C: **0**

**Every cell finished within half a degree of every other.** That is the model, not the pack: no fans are placed and the airflow field is uniform, so there is nothing here to make cells differ. The gradient is precisely what you came for, and it only appears once fans and duct geometry go in — which is the 🌡️ Pack Thermal tab's job, not this lane's.

*One lap from cold. Endurance is twenty-two of these back to back, so treat this as the gradient's shape rather than the temperature you will actually see. The 🌡️ Pack Thermal tab runs the full event and will place fans against it.*
