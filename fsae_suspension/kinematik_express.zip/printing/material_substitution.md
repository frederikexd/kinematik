# Printed part — what the substitution costs

Duty: **80 °C**, sustained load, principal stress across the layers, filament not stated as dried and sealed. Design FoS 3.

### PAHT-CF (high-temperature carbon-filled nylon) → Markforged Onyx (micro-carbon-filled nylon)

MATERIAL CHANGE, NOT A SUBSTITUTION. The replacement carries 35% of the allowable stress at this duty. Any FEA run against the original material is void.

| | wanted | got |
|---|---|---|
| datasheet in-plane | 95 MPa | 40 MPa |
| HDT | 190 °C | 145 °C |
| **allowable at this duty** | **22.8 MPa** | **7.9 MPa** |
| working stress (÷FoS) | 7.6 MPa | 2.6 MPa |

### Where the strength went

| knockdown | factor | why |
|---|---|---|
| orientation | ×0.45 | principal stress crosses the layers — 45% of the in-plane number, because that is what the layer bond carries |
| temperature | ×1.00 | 80 °C is below the 85 °C knee — no knockdown |
| creep | ×0.55 | sustained load at elevated temperature — 55% to cover creep, which a static FEA does not see |
| moisture | ×0.80 | nylon-based and not stated as dried/sealed — 20 % off. A part printed from wet filament and left in a humid garage is measurably weaker than its datasheet |
| **total** | **×0.20** | |

That column is the answer to *why does the datasheet say 40 MPa and you say 6*. None of those four is optional and none of them appears in a default isotropic FEA material card.

### What to do about it

- Re-run the FEA with 7.9 MPa allowable, not the datasheet number.
- Wall thickness scales roughly as 1/allowable for pressure parts — expect about 2.9× the wall.
- The replacement accepts continuous-fibre reinforcement. That buys in-plane strength only, so it helps if — and only if — you also change the print orientation so the principal stress runs along the fibres.
- Dry the filament and seal the part. It is the cheapest 20 % on this list.

### The manifold as a pressure vessel

25 mm bore × 3 mm wall at 1.1 bar.

| print orientation | hoop (MPa) | FoS | min wall for FoS 3 |
|---|---|---|---|
| upright (layers around the hoop) | 0.46 | **17.28** | 0.5 mm |
| lying down (hoop in-plane) | 0.46 | **38.40** | 0.2 mm |

**Print orientation is worth 2.2× on this part** and costs nothing. It is a structural decision, and it is currently being made by whoever loads the plate.

- Hoop 0.46 MPa, axial 0.23 MPa, allowable 7.92 MPa after knockdowns.
- Printed upright, so the hoop stress — the bigger of the two — pulls straight across the layer bond. Printing it lying down puts the hoop direction in-plane and leaves only the axial stress on the weak axis, which is a free factor of two.
- Nylon-based and in permanent contact with hot glycol. Fluid compatibility and long-term swelling are not modelled here and are a real failure mode for printed wet parts — soak a coupon for a fortnight before you trust a season on it.
- Thin-wall formula, no stress concentrations. Every port, boss, flange fillet and printed thread is a concentration this does not see, and printed parts are notch-sensitive. Treat the wall as the easy half of the problem.

*Material data are published datasheet values (Markforged published datasheet) from someone else's printer, not coupons from yours. Takes continuous carbon/glass/Kevlar reinforcement, which is the only route to a large strength gain — and it reinforces IN-PLANE only, so it does nothing for the across-layer direction that usually governs. Print and pull your own coupons in the same orientation as the part — it is a day of work and it replaces every assumption on this page.*
