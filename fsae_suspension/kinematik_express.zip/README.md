# Your KinematiK bundle

You asked for this in two sentences. Here is what was run, on what, and what every number is worth.

> **Nothing in this pipeline is a language model.** The request was read by a keyword grammar and a nearest-quantity binder; the data by a delimiter sniffer and a synonym table. Both print their receipts below, including what they did not understand.

**12 files** · 5 jobs run, 0 deferred, 0 skipped, 0 failed.

Time budget: **90 s** (the lane default — nothing in your sentence set one).

## What you said

> Our print bureau only stocks Onyx, not PAHT-CF. 80 kW, coolant temperature 80, 25 mm bore 3 mm wall. Check the cooling loop, the test rig instrumentation, the printed manifold, the gear ratio and the tractive system.

### The parse receipt

- ✅ '80' beside 'coolant temperature' → coolant_c = 80  (dimensionless)
- ✅ '3 mm' beside 'wall' → wall_mm = 3
- ✅ '25 mm' beside 'bore' → bore_mm = 25
- ✅ '80 kW' → power_kw = 80 (inferred from the unit alone — no parameter word nearby)
- ✅ 'cooling' → the cooling engine
- ✅ 'printed' → the printing engine
- ✅ 'gear ratio' → the powertrain engine
- ✅ 'temperature' → the thermal engine
- ✅ 4 of 4 numbers bound to parameters
- ➖ assumed: no output format named — shipping all three (report, CSV, JSON)
- ➖ assumed: no time budget stated — using the lane default of 90 s; say 'I have five minutes' and the expensive engines become available
- 🕳️ not understood (a grammar, not a language model): bureau, check, instrumentation, loop, not, only, paht-cf, print, stocks, system

### Parameters the run used

| parameter | value | source |
|---|---|---|
| `track_front_mm` | 1200 | default |
| `track_rear_mm` | 1180 | default |
| `wheelbase_mm` | 1550 | default |
| `cg_height_mm` | 300 | default |
| `weight_dist_front` | 0.47 | default |
| `mass_kg` | 280 | default |
| `lateral_g` | 1.4 | default |
| `long_g` | 1.5 | default |
| `brake_bias_front` | 0.62 | default |
| `spring_rate_N_per_mm` | 35 | default |
| `travel_mm` | 25 | default |
| `mu_peak` | 1.55 | default |
| `coolant_c` | 80 | **from your sentence** |
| `flow_lpm` | 12 | default |
| `cap_bar` | 1.1 | default |
| `wall_mm` | 3 | **from your sentence** |
| `bore_mm` | 25 | **from your sentence** |
| `rad_ua` | 120 | default |
| `motor_torque_nm` | 140 | default |
| `wheel_radius_mm` | 228 | default |
| `pack_kwh` | 6.5 | default |
| `power_kw` | 80 | **from your sentence** |
| `endurance_laps` | 22 | default |
| `rotor_dia_mm` | 220 | default |

Every default above is a declared constant, not a hidden one. If one is wrong for your car, put the right number in the sentence and re-run — the binder will pick it up.

## What you dropped

No files were dropped, so every job ran on declared defaults and the built-in FSAE front corner. The geometry is real; the vehicle numbers are placeholders until you give it yours.

## What was run

| job | tool | why it ran |
|---|---|---|
| Cooling loop sizing | ❄️ Cooling Loop | asked for by name |
| Printed-part material substitution | 🖨️ Printed Parts | asked for by name |
| Cooling rig instrumentation budget | ❄️ Cooling Loop | asked for by name |
| Gear ratio sweep | ⚙️ Powertrain | asked for by name |
| Pack thermal over a lap | 🌡️ Pack Thermal | asked for by name |

## Read this before you quote any of it

This bundle is a **screening artifact**. Every job ran at coarse, declared fidelity so it could finish while you waited. That makes it an excellent starting point for a design review and a poor place to stop:

Take these past screening fidelity in their own tabs: **❄️ Cooling Loop**, **⚙️ Powertrain**, **🖨️ Printed Parts**, **🌡️ Pack Thermal**.

And the standing rule this toolkit exists for: do this here first so that ANSYS / MATLAB / ADAMS spend their time **validating** your design instead of debugging your inputs.

## Files in this bundle

- `cooling/loop_sizing.csv`
- `cooling/loop_sizing.md`
- `cooling/rig_instrumentation.md`
- `cooling/sensor_matrix.csv`
- `powertrain/gear_ratio.md`
- `powertrain/gear_ratio_sweep.csv`
- `printing/knockdowns.csv`
- `printing/material_substitution.md`
- `thermal/cell_temps.csv`
- `thermal/pack_thermal.md`
- `manifest.json` — the whole run, machine-readable

---

*KinematiK Express Lane · deterministic: the same sentence and the same files produce a byte-identical ZIP, every time.*
